const  authJwt= require('./middleWares/middleWares').authJwt;

module.exports = {
    authJwt:authJwt,
}