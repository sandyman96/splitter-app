const db = require('./config/dbFromenv');
module.exports = db;