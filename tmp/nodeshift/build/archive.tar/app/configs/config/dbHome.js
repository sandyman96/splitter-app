module.exports = {
    host: 'localhost',
    user: 'splitter',
    password: 'splitter',
    database: 'splitter',
}